/* */
var readlinesync = require('readline-sync');
var fs = require('fs');

const student2 =[];


function loadData(){
  var fileContent = fs.readFileSync('./data.json');
  student2 ==  JSON.parse (fileContent);
}

function showStudents(){
  for (var student of student2){
    console.log(student.name, student.age);
  }
}

function  showCreateStudent(){
  var name = readlinesync.question('Name:  ');
  var age = readlinesync.question('Age:  ');
  var student ={};
    student.name = name;
    student.age = parseInt(age);
  
  student2.push(student);
}
function saveAndExit(){
  var content = JSON.stringify(student2);
  fs.writeFileSync('./data.json', content , { encoding: 'utf8'});
}

function showMenu(){
  console.log("1. show all student.");
  console.log("2. Create a new student.");
  console.log("3. Save and exit. ");

  var option = readlinesync.question('>');
  switch(option){
    case '1':
    showStudents();
    showMenu();
    break;
    case '2':
    showCreateStudent();
        showMenu();
    break;
    case '3':
    saveAndExit();
    break;
    default:
    console.log("Wrong option");
    break;
  }
}

function main(){
  loadData();
  showMenu();
}
main()